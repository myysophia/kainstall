## ArgoCD Example

This is the simplest, working example of an argocd app, the JSON object built is now an array of objects as that is the prefered format for ArgoCD.

Requirements:

**ArgoCD 1.7+**

Follow the vendor generation steps at the root of this repository and generate a `vendored` folder (referenced in `application.yaml`).
